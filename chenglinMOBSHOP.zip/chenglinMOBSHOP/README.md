# MobileShop
Create for NetworkProject_17th in Jiaxing University. Also welcome for anyone studying
------------------------------------------------------------------------------------------------------------------------------------------

Something you need to know:

1.Before you run MobileShop Project,make sure had start your Tomact Server 

2.In com.coalbrother.mobileshop.common.Constants.java,update the ip to the native ip
